#include "calculator.h"

int main() {
    return RunCalculatorCycle() ? 0 : 1;
}


// В этом файле только функция main и #include-директивы.