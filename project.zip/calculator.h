# pragma once

#include <iostream>
#include <string>// В этом файле объявления функций.

using Number = double;

bool ReadNumber(Number& result);
bool RunCalculatorCycle(); //Функция команд
